package com.example.a1;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {

    private Button rButton;
    private Button aButton;
    private static final String PERM_TOAST = "edu.uic.cs478.sp.project3";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rButton = findViewById(R.id.button);
        aButton = findViewById(R.id.button2);

        rButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                checkPermissionAndBroadcast(1);
            }
        });
        aButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                checkPermissionAndBroadcast(2);
            }
        });
    }

    private void checkPermissionAndBroadcast(int i) { // check if granted else call back to next function
        if (ContextCompat.checkSelfPermission(this, PERM_TOAST)
                == PackageManager.PERMISSION_GRANTED) {
            if(i == 1) {
                Intent aIntent = new Intent();
                aIntent.setAction("com.example.a1.Restaurant");
                sendBroadcast(aIntent);
        }
            else
            {
                Intent aIntent = new Intent();
                aIntent.setAction("com.example.a1.Attraction");
                sendBroadcast(aIntent);
            }
        }
        else {
            ActivityCompat.requestPermissions(this, new String[]{PERM_TOAST}, i);
        }

    }

    public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {// pop up window to choose to grant
        if (results.length > 0) {
            if (results[0] == PackageManager.PERMISSION_GRANTED) {
                if (code == 1) {
                    Intent aIntent = new Intent();
                    aIntent.setAction("com.example.a1.Restaurant");
                    sendBroadcast(aIntent);
                } else {
                    Intent aIntent = new Intent();
                    aIntent.setAction("com.example.a1.Attraction");
                    sendBroadcast(aIntent);
                }
            }
            else {
                Toast.makeText(this, "Bummer: No permission", Toast.LENGTH_SHORT)
                        .show();
            }
        }
    }
}
