package com.example.a2;

import android.content.ClipData;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import androidx.fragment.app.FragmentActivity;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.example.a2.ItemFragment.ListSelectionListener;

import static android.content.res.Configuration.ORIENTATION_PORTRAIT;

public class AttractionActivity extends FragmentActivity implements ListSelectionListener {

    public static String[] attArr;
    private androidx.fragment.app.FragmentManager fragManager;
    private final WebFragment webFragment = new WebFragment();
    private FrameLayout listFLayout, webFLayout;
    private static final int MATCH_PARENT = LinearLayout.LayoutParams.MATCH_PARENT;

    private final static String TAG = "AttractionActivity";

    @Override
    public void onConfigurationChanged(Configuration newConfig){
        super.onConfigurationChanged(newConfig);
        setLayout();
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        attArr = getResources().getStringArray(R.array.Attractions);


        setContentView(R.layout.act);



        listFLayout = (FrameLayout) findViewById(R.id.list_frag_cont);
        webFLayout = (FrameLayout) findViewById(R.id.web_frag_cont);


        fragManager = getSupportFragmentManager();

        androidx.fragment.app.FragmentTransaction fragTransaction = fragManager.beginTransaction();

        fragTransaction.replace(R.id.list_frag_cont,
                new ItemFragment());


        fragTransaction.commit();


        fragManager.addOnBackStackChangedListener(
                // UB 2/24/2019 -- Use support version of Listener
                new androidx.fragment.app.FragmentManager.OnBackStackChangedListener() {
                    public void onBackStackChanged() {
                        Log.w(TAG, "In onBackStackChanged");
                        setLayout();
                    }
                });
    }

    private void setLayout() {
        Log.w(TAG, "In setLayout");        //Change later to fit correctly
        Configuration config = getResources().getConfiguration();
        if(config.orientation == ORIENTATION_PORTRAIT){
            if (!webFragment.isAdded()) {
                Log.w(TAG, "In setLayout PORTRAIT if statement");
                // Make the TitleFragment occupy the entire layout
                listFLayout.setLayoutParams(new LinearLayout.LayoutParams(
                        MATCH_PARENT, MATCH_PARENT));
                webFLayout.setLayoutParams(new LinearLayout.LayoutParams(0,
                        MATCH_PARENT));
            }
            else{
                Log.w(TAG, "In setLayout PORTRAIT else statement");
                listFLayout.setLayoutParams(new LinearLayout.LayoutParams(
                        0, 0));
                webFLayout.setLayoutParams(new LinearLayout.LayoutParams(MATCH_PARENT,
                        MATCH_PARENT,2f));
            }
        }

       /* else {
            if (!webFragment.isAdded()) {
                Log.w(TAG, "In setLayout LANDSCAPE if statement");
                // Make the TitleFragment occupy the entire layout
                listFLayout.setLayoutParams(new LinearLayout.LayoutParams(
                        0, MATCH_PARENT, 1f));
                webFLayout.setLayoutParams(new LinearLayout.LayoutParams(0,
                        MATCH_PARENT, 2f));
            }
            else{
                Log.w(TAG, "In setLayout LANDSCAPE else statement");
                // Make the TitleLayout take 1/3 of the layout's width
                listFLayout.setLayoutParams(new LinearLayout.LayoutParams(0,
                        MATCH_PARENT, 1f));

                // Make the QuoteLayout take 2/3's of the layout's width
                webFLayout.setLayoutParams(new LinearLayout.LayoutParams(0,
                        MATCH_PARENT, 2f));
            }
        }*/
    }

    // Implement Java interface ListSelectionListener defined in TitlesFragment
    // Called by TitlesFragment when the user selects an item in the TitlesFragment
    @Override
    public void onListSelection(int index) {
        Log.w(TAG, "In onListSelection");

        if (!webFragment.isAdded()) {
            Log.w(TAG, "In onListSelection 1st if");
            // Start a new FragmentTransaction
            // UB 2/24/2019 -- Now must use compatible version of FragmentTransaction
            androidx.fragment.app.FragmentTransaction fragmentTransaction = fragManager
                    .beginTransaction();

            // Add the QuoteFragment to the layout
            fragmentTransaction.add(R.id.web_frag_cont, webFragment);
            fragmentTransaction.commit();
            // Add this FragmentTransaction to the backstack
            fragmentTransaction.addToBackStack(null);

            // Force Android to execute the committed FragmentTransaction
            fragManager.executePendingTransactions();
        }

        if (webFragment.getShownIndex() != index) {
            Log.w(TAG, "In onListSelection 2nd if");
            // Tell the QuoteFragment to show the quote string at position index
            webFragment.showSiteAtIndex(index, 1);
        }

    }
}
