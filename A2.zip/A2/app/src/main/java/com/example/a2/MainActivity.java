package com.example.a2;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.os.Bundle;

public class MainActivity extends Activity {

    private Receiver rec = new Receiver();
    private IntentFilter filter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        filter = new IntentFilter();
        filter.addAction("com.example.a1.Restaurant");
        filter.addAction("com.example.a1.Attraction");
        filter.setPriority(1);
        rec = new Receiver();
        registerReceiver(rec, filter);

        setContentView(R.layout.activity_main);
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        unregisterReceiver(rec);
    }
}
