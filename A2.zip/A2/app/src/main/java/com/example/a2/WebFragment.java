package com.example.a2;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.fragment.app.Fragment;

public class WebFragment extends Fragment {
    private int curIndex = -1;
    private String[] aURLS;
    private String[] rURLS;
    private String url;
    private WebView mWebView;

    private static final String TAG = "WebFragment";

    int getShownIndex() {return curIndex;}

    void showSiteAtIndex(int index, int act){

        curIndex = index;
        if(act == 1)
            mWebView.loadUrl(aURLS[curIndex]);
        else
            mWebView.loadUrl(rURLS[curIndex]);

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        aURLS = getResources().getStringArray(R.array.Attraction_urls);
        rURLS = getResources().getStringArray(R.array.Restaurant_urls);
        setRetainInstance(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Log.w(TAG, "OnCreateView called");
        View v = inflater.inflate(R.layout.web, container, false);
        mWebView = (WebView)v.findViewById(R.id.webViewFrag);
        mWebView.setWebViewClient(new WebViewClient());
        mWebView.getSettings().setJavaScriptEnabled(true);

        return v;
    }
    @Override
    public void onAttach(Context context){
        super.onAttach(context);
    }
}
